package br.com.matheusreinheimer.introspring.model;

public enum Genre {
    MASCULINO, FEMININO
}
