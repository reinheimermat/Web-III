import java.time.LocalDate;
import java.time.Month;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");

        endereco Endereco = new endereco();
        Endereco.rua = "Rua Imaginaria";
        Endereco.numero = 2674;
        Endereco.bairro = "São Borja";
        Endereco.cidade = "São Leopoldo";
        Endereco.estado = "Rio Grande do Sul";
        Endereco.cep = 93146-00;

        internacao Internacao = new internacao();
        Internacao.medicoResponsavel = "Jorjão Embreagem";
        Internacao.paciente = "Thomas Turbando";
        Internacao.dataInternacao = LocalDate.of(2020, Month.DECEMBER, 14);
        Internacao.dataAlta = LocalDate.of(2021, Month.JANUARY, 10);
        Internacao.observacoes = "Boa Recuperação";

        medico Medico = new medico();
        Medico.CRM = "Operacional";
        Medico.nomeCompleto = "Tokoku Navara";
        Medico.endereco = "Rua Japão da Africa 778, Irlanda do Sul";
        Medico.telefone = 579123456;

        paciente Paciente = new paciente();
        Paciente.nomeCompleto = "Fugino Kombi";
        Paciente.RG = "75757575748";
        Paciente.CPF = "123456765-89";
        Paciente.telefoneContato = "5175849322";
        Paciente.endereco = "Rua Biluga 346, Jardim America";
    }
}
