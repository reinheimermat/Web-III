public class endereco {
    public String rua;
    public float numero;
    public String bairro;
    public String cidade;
    public String estado;
    public double cep;

    public String getRua() {
        return this.rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public float getNumero() {
        return this.numero;
    }

    public void setNumero(float numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return this.bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return this.cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return this.estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getCep() {
        return this.cep;
    }

    public void setCep(double cep) {
        this.cep = cep;
    }
}