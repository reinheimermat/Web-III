import java.time.LocalDate;

public class vendedor {
    public String nome;
    public LocalDate nascimento;
    public String cpf;
    public float salario;
    public String endereco;
}
