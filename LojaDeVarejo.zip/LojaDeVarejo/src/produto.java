public class produto {
    public String nomeProduto;
    public float valorProduto;
    public String codProduto;
    public String cupomProduto;
    public String descriscaoProduto;
}
