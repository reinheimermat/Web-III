public class fornecedor {
    public String nome;
    public String razaoSocial;
    public long cnpj; 
}
