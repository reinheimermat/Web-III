public class transportadora {
    public String nomeTransportadora;
    public String cnpj;
    public String nomeMotorista;
    public String enderecoEntrega;
    public String codEntrega;
}
