import java.time.LocalDate;

public class cliente {
    public String nome;
    public String sobrenome;
    public long telefone;
    public LocalDate dataDeNascimento;
    public long cpf;
    public String email;
    public String endereco;
}
