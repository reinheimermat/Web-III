import java.util.Scanner;

// # Atividade 1

// Faça um programa para a leitura de duas notas parciais de um aluno.

// - Escreva a mensagem “Aprovado com Distinção”, se a média for maior ou igual a 9;
// - Escreva a mensagem “Aprovado”, se a média alcançada for maior ou igual a seis;
// - Escreva a mensagem “Reprovado” se a média for menor de do que sete;

public class ex001 {
    nota1 = 9;
    nota2 = 10;
    media = (nota1 + nota2) / 2;

    if(media >= 9) {
        System.out.println("Aprovado com Distinção");
    } else if (media >= 6) {
        System.out.println("Aprovado");
    } else if (media < 7){
        System.out.println("Reprovado");
    }
}

